<?php
namespace server\Core\utils;
class Json {
	private $filesrc;
	private $file;
	private $filename;
	private $data;

	public function __construct($name) {
		$this->filesrc = $_SERVER['DOCUMENT_ROOT']."/config/$name.json";
		$this->filename = "$name.json";
		$this->data = json_decode(file_get_contents("php://input"));
		if (file_exists($this->filesrc)) {
			$this->file = file_get_contents($this->filesrc);
		} else {
			$this->file = fopen($this->filesrc, "a+");
		}
	}

	public function getName() {
		return $this->filename;
	}

	public function setJson(array $arr) {
		$taskList = json_decode($this->filesrc, true);
		$taskList = $arr;
		file_put_contents($this->filesrc, json_encode($taskList));
	}

	public function getJson($arg = 0) {
		$file = json_decode($this->filesrc, true);
		return $file[$arg];
	}
}