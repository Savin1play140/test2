<?php
namespace server\Core\utils;
class Load {
	private $vaule = 0;
	private $max;
	private $tag = "progress";
	public function __construct() {
		$this->setMax(100);
	}
	public function getMax() {
		return $this->max;
	}
	public function setMax($int) {
		$this->max = $int;
	}
	public function getVaule() {
		return $this->vaule;
	}
	public function setVaule($int) {
		$this->vaule = $int;
	}
	public function addVaule($int) {
		$this->vaule += $int;
	}
	public function __destruct() {
		$tag = $this->tag;
		$max = $this->max;
		$vaule = $this->vaule;
		echo "<$tag max=\"$max\" vaule=\"$vaule\"></$tag>";
	}
}