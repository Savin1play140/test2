<?php
namespace server\Core\system;
class Log {
	private $messages = [];
	public function message(string $text1) {
		$this->messages[] = "[SERVER-LOG-MESSAGE] $text1";
	}
	public function alert(string $text) {
		$this->messages[] = "[SERVER-LOG-ALERT] $text";
	}
	public function warning(string $text2) {
		$this->messages[] = "[SERVER-LOG-WARNING] $text2";
	}
	public function error(string $text3) {
		$this->messages[] = "[SERVER-LOG-ERROR] $text3";
	}
	private function sendLog() {
		foreach ($this->messages as $msg) {
			if ($msg !== null) {
				echo "$msg<br>";
			}
		}
	}
	public static function getInstance(): self {
		return self;
	}
	public function __construct() {}
	public function __destruct() {
		$this->sendLog();
	}
}
?>