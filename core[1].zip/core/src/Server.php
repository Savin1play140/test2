<?php

namespace server\Core;

use server\Core\system\Log;
use server\Core\plugins\PluginManager;
use server\Core\textures\TextureManager;
use server\Core\math\Vector2;
use server\Core\network\protocol\Control;
use server\Core\network\User;
use server\Core\network\Console;
use server\Core\math\Calc;
use server\Core\language\Lang;

class Server {
	private $log;
	private $manager;
	private $protocol;
	private $name;
	public function getLog(): Log {
		return $this->log;
	}
	public function getProtocol(): Control {
		return $this->protocol;
	}
	public function getUser(): User {
		return new User("Client");
	}
	public function getConsole(): Console {
		return new Console($this);
	}
	public function getCalculator($x, $y): Calc {
		return new Calc($x, $y);
	}
	public function __construct($log) {
		$this->log = $log;
		$this->manager = new PluginManager($this, $this->log);
		$this->protocol = new Control();
	}
	public static function getInstance(): Server {
		if (self === null) {
			throw new \ServerError("Attempt to retrieve Server instance outside server thread");
		}
		return self;
	}
	public function getPluginManager() {
		return $this->manager;
	}
	public function getTextureManager() {
		return new TextureManager();
	}
	public function generatNum(?int $count = 4) {
		$chars = "012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789";
		return substr(str_shuffle($chars), 0, $count);
	}
	public function generatStr(?int $count = 4) {
		$chars = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm";
		return substr(str_shuffle($chars), 0, $count);
	}
	public function ServerVersion() {
		return "1.0.01";
	}
	public function PHPVersion() {
		$php = PHP_VERSION;
		return $php !== "" ? $php : "error";
	}
	public function getServerName() {
		return $this->name;
	}
	protected function setServerName($name) {
		$name = $this->name;
	}
	public function getIp(): string {
		$ip = $_SERVER['SERVER_ADDR'];
		return $ip !== "::1" ? $ip : "0.0.0.0";
	}
	public function getPort(): string {
		$port = $_SERVER['SERVER_PORT'];
		return $port !== "" ? $port : "80";
	}
	public function getDateRelease() {
		return date_format(date_create("2022-10-20"), "Y.m.d");
	}
	public function getServerDir(): string {
		$doc_root = $_SERVER['DOCUMENT_ROOT'];
		return $doc_root !== "/root" ? $doc_root : "default";
	}
	public function getAuthors(): string {
		return "GMP14, KUB";
	}
	static function getServer() {
		return self;
	}
}