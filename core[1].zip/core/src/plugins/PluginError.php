<?php
class PluginError extends Error {}