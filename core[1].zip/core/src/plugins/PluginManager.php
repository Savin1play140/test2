<?php
namespace server\Core\plugins;
use server\Core\Server;
use server\Core\system\Log;

class PluginManager {
	private $server;
	private $log;
	public function __construct(Server $server, Log $log) {
		$this->server = $server;
		$this->log = $log;
	}
	public function loadAll() {
		$dir = $_SERVER["DOCUMENT_ROOT"]."/plugins/";
		$files = scandir($dir);
		foreach ($files as $file) {
			if (!str_contains($file, ".")) {
				echo "[SERVER-LOG-ALERT] plugin ".$file." enabled!<br>";
				$plugs = scandir($dir.$file."/src");
				foreach ($plugs as $plug) {
					@include_once $dir.$file."/src/".$plug;
					$plug = $plug !== ".." ? $plug : null;
					$plug = $plug !== "." ? $plug : null;
					if ($plug != null) {
						$class = str_replace(".php", "", $plug);
						$plugin = new $class($this->server, $this->log, $this);
						if (!$plugin instanceof PluginBase) {
							throw new \PluginError("plugin does not inherit class PluginBase! in file \"$dir$file/src/$plug\" a plugin $file");
						}
					}
				}
			}
		}
	}
}