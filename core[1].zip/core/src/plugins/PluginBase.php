<?php
namespace server\Core\plugins;

use server\Core\Server;
use server\Core\system\Log;

abstract class PluginBase {
	public function __construct(
		private Server $server,
		private Log $log,
		private PluginManager $plugin
	) {
		$this->onEnable();
	}
//on enable
	protected function onEnable(): void {

	}
//on disable (does not work)
	protected function onDisable() : void{

	}
	public function getServer(): Server {
		return $this->server;
	}
	public function getLog(): Log {
		return $this->log;
	}
	public function getManager(): PluginManager {
		return $this->plugin;
	}
/*	public function __destruct() {
		$this->onDisable();
	}*/
}