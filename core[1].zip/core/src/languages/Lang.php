<?php
namespace server\Core\language;
class Lang {
	private $sours;
	public function __construct() {
		$file = file_get_contents($_SERVER["DOCUMENT_ROOT"]."/language.json");
		$this->sours = json_decode($file, true);
	}
	public function getLable(string $lang, string $arg) {
		return $this->sours[$lang][$arg];
	}
}