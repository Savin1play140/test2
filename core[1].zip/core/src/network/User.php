<?php
namespace server\Core\network;
use server\Core\Server;

class User implements Sender {
	private $name;
	public function __construct($name = "User") {
		$this->name = $name;
	}
	public function getServer(): Server {
		return new Server();
	}
	public function getName(): string {
		return $this->name;
	}
	public function sendMessage(string $message):void {
		echo "<font color=\"grey\">$message</font>";
	}
	public function getIp(): string {
		$ip = $_SERVER['REMOTE_ADDR'];
		return $ip !== "::1" ? $ip : "0.0.0.0";
	}
	public function getPort(): string {
		$port = $_SERVER['REMOTE_PORT'];
		return $port !== "" ? $port : "80";
	}
}