<?php
namespace server\Core\network\protocol;

class Control {
	public function __construct() {}
	public function sendE4() {
		include_once "E4.php";
	}
	public function sendE9() {
		include_once "E9.php";
	}
	public function sendE14() {
		include_once "E14.php";
	}
	public function sendE17() {
		include_once "E17.php";
	}
}
