<?php
class ServerError extends Error {}