<?php
class AppError extends Error {}