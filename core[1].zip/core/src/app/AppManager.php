<?php
namespace server\Core\app;
use server\Core\Server;
use server\Core\system\Log;
class AppManager {
	private $server;
	private $log;
	public function __construct(Server $server, Log $log) {
		$this->server = $server;
		$this->log = $log;
	}
	public function loadAll() {
		$dir = $_SERVER["DOCUMENT_ROOT"]."/apps/";
		@mkdir($dir);
		$files = scandir($dir);
		foreach ($files as $file) {
			if (!str_contains($file, ".")) {
				echo "[SERVER-LOG-ALERT] app $file enabled!<br>";
				$apps = scandir($dir.$file."/");
				foreach ($apps as $app) {
					@include_once $dir.$file."/".$app;
					$app = $app !== ".." ? $app : null;
					$app = $app !== "." ? $app : null;
					if ($app != null) {
						$class = str_replace(".php", "", $app);
						$appc = new $class($this->server, $this->log, $this);
						if (!$appc instanceof AppBase) {
							throw new \AppError("plugin does not inherit class PluginBase! in file \"$dir$file/src/$plug\" a plugin $file");
						}
					}
				}
			}
		}
	}
}