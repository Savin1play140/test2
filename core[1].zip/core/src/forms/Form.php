<?php
namespace server\Core\forms;

class Form {
	protected $name;
	protected $title;
	protected $type;
	private $content = [];
	public function __construct($name, $title, $type = 0) {
		$this->name = $name;
		$this->title = $title;
		$this->type = $type;
		$this->content = ["name" => $name, "title" => $title, "type" => $type];
	}
	public function addButton($name, $text, $func):void {
		$this->content["button"] = ["name" => $name, "text" => $text, "function" => $func];
	}
	public function addInput($name, $text, $value):void {
		$this->content["input"] = ["name" => $name, "text" => $text, "value" => $value];
	}
	public function addText($text):void {
		$this->content["text"] .= "$text\0\n";
	}
	public function getContent($value) {
		return $this->content[$value];
	}
}
$form = new Form("Form", "test");
$form->addText("1");
$form->addText("2");
$form->addButton("top", "click", "gm");
print_r($form->getContent("button"));
echo $form->getContent("name");
